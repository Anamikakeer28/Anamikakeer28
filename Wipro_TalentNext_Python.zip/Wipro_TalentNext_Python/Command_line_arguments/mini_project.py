# Mini Project 1: Travel Suggestion Based on Distance

# Ask user for the travel distance
distance = float(input("How far would you like to travel in miles? "))

# Suggest transport mode based on distance
if distance < 3:
    print("I suggest Bicycle to your destination")
elif 3 <= distance < 300:
    print("I suggest Motor-cycle to your destination")
else:
    print("I suggest Super-Car to your destination")


# Mini Project 2: Server Cost Calculation

# Hosting provider cost per hour
cost_per_hour = 0.51

# Calculate cost
cost_per_day = cost_per_hour * 24
cost_per_week = cost_per_day * 7
cost_per_month = cost_per_day * 30

# Given budget
budget = 918

# Calculate how many days the server can run with the given budget
days_with_budget = budget / cost_per_day

# Display the results
print(f"Cost to operate one server per day: ${cost_per_day:.2f}")
print(f"Cost to operate one server per week: ${cost_per_week:.2f}")
print(f"Cost to operate one server per month: ${cost_per_month:.2f}")
print(f"With ${budget}, you can operate one server for {days_with_budget:.2f} days.")