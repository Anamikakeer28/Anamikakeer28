#Q1. Check if a number is Positive, Negative, or Zero

num = int(input("Enter a number: "))
if num > 0:
    print("Positive")
elif num < 0:
    print("Negative")
else:
    print("Zero")




#Q2. Check if a number is Odd or Even

num = int(input("Enter a number: "))
if num % 2 == 0:
    print("Even")
else:
    print("Odd")



#Q3. Check if two non-negative numbers have the same last digit

a = int(input("Enter first number: "))
b = int(input("Enter second number: "))
if a >= 0 and b >= 0:
    if a % 10 == b % 10:
        print("True")
    else:
        print("False")
else:
    print("Both numbers must be non-negative.")




#Q4. Print numbers from 1 to 10 in one row with tab space

for i in range(1, 11):
    print(i, end="\t")




#Q5. Print even numbers between 23 and 57, each in a new line

for i in range(23, 58):
    if i % 2 == 0:
        print(i)


#Q6. Check if a number is prime

num = int(input("Enter a number: "))
if num < 2:
    print("Not a Prime Number")
else:
    for i in range(2, int(num**0.5) + 1):
        if num % i == 0:
            print("Not a Prime Number")
            break
    else:
        print("Prime Number")


#Q7. Print prime numbers between 10 and 99

for num in range(10, 100):
    is_prime = True
    if num < 2:
        is_prime = False
    else:
        for i in range(2, int(num**0.5) + 1):
            if num % i == 0:
                is_prime = False
                break
    if is_prime:
        print(num)



#Q8. Sum of all digits of a number

num = int(input("Enter a number: "))
sum_digits = 0
while num > 0:
    sum_digits += num % 10
    num //= 10
print("Sum of digits:", sum_digits)



#Q9. Reverse a given number

num = int(input("Enter a number: "))
reverse = 0
while num > 0:
    reverse = reverse * 10 + num % 10
    num //= 10
print("Reversed number:", reverse)



#Q10. Check if the number is a palindrome

num = int(input("Enter a number: "))
original = num
reverse = 0
while num > 0:
    reverse = reverse * 10 + num % 10
    num //= 10
if original == reverse:
    print("Palindrome")
else:
    print("Not a Palindrome")

